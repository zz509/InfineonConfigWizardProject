/*
 ***********************************************************************************************************************
 *
 * Copyright (c) 2015, Infineon Technologies AG
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,are permitted provided that the
 * following conditions are met:
 *
 *   Redistributions of source code must retain the above copyright notice, this list of conditions and the  following
 *   disclaimer.
 *
 *   Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
 *   following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 *   Neither the name of the copyright holders nor the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **********************************************************************************************************************/

/*******************************************************************************
**                             Author(s) Identity                             **
********************************************************************************
** Initials     Name                                                          **
** ---------------------------------------------------------------------------**
** DM           Daniel Mysliwitz                                              **
** BG           Blandine Guillot                                              **
** JO           Julia Ott                                                     **
*******************************************************************************/

/*******************************************************************************
**                          Revision Control History                          **
********************************************************************************
** V1.0.0: 2020-10-20, JO:   Initial version of the example                   **
** V1.1.0: 2020-12-18, BG:   EP-652: Corrected name of error code variable    **
**                           clear Watchdog fail status                       **
**                           clear fail safe status flags                     **
**                           clear bridge driver status flags                 **
** V1.1.1: 2021-02-03, JO:   EP-684: Fixed MISRA errors in main.c file        **
** V1.2.0: 2021-03-11, JO:   EP-689: Updated file debug.ini to support        **
**                           resetting the device in Debugger (with ULINK2,   **
**                           the CPU needs to be halted before Reset),        **
**                           Required scu file version: 0.4.0                 **
**                           Updated to main template V1.5.3                  **
*******************************************************************************/

/*******************************************************************************
**                                  Abstract                                  **
********************************************************************************
** Getting started: Getting started Project with all components and the       **
** required settings in the 'Options for Target' dialog                       **
********************************************************************************
** 'Options for Target' setting:                                              **
** --> Target: Uncheck IROM2 and IRAM2, Check Use MicroLIB                    **
** --> C/C++ (AC6): Change Optimization from Oz to O0                         **
** --> ASM: Change Assembler Option from armclang to armasm                   **
** --> Debug: Uncheck "Run to main", Add ini file provided in this project    **
**     content of ini file with filename debug.ini:                           **
**     FUNC void OnResetExec(void) {                                          **
**       SP = _RWORD(0x11000080);                                             **
**       PC = _RWORD(0x11000084);                                             **
**     }                                                                      **
**     SP = _RWORD(0x11000080)                                                **
**     PC = _RWORD(0x11000084)                                                **
** --> Debug --> Settings: Change connect from Normal to With Pre-Reset,      **
**     Change Reset from Autodetect to VECTRESET                              **
*******************************************************************************/

/*******************************************************************************
**                                  Includes                                  **
*******************************************************************************/
#include "tle_device.h"
#include "types.h"

/*******************************************************************************
**                        Global Constant Declarations                        **
*******************************************************************************/

/*******************************************************************************
**                          Global Type Declarations                          **
*******************************************************************************/

/*******************************************************************************
**                          Global Macro Declarations                         **
*******************************************************************************/

/*******************************************************************************
**                        Global Function Declarations                        **
*******************************************************************************/

/*******************************************************************************
**                     Global Inline Function Definitions                     **
*******************************************************************************/

sint32 main(void)
{
  /* Clear watchdog fail status */
  PMU_clrFailSafeWatchdogFailSts();
  
  /* Initialization of hardware modules based on Config Wizard configuration */
  (void)TLE_init();

  /* Clear fail safe status flags */
  while (PMU->FS_STS.reg != 0)
  {
    PMU->FS_STS_CLR.reg = 0xFFFFFFFFU;
  }
  while (PMU->FS_SSD.reg != 0)
  {
    PMU->FS_SSD_CLR.reg = 0xFFFFFFFFU;
  }
  
  /* Clear bridge driver status flags */
  BDRV->STSCLR.reg = 0xFFFFFFFFU;
  
  /*****************************************************************************
  ** Place your application code here                                         **
  *****************************************************************************/
  CCU7_startT12();
	BDRV_setBridge(BDRV_chCfg_pwm , BDRV_chCfg_pwm , BDRV_chCfg_pwm , BDRV_chCfg_pwm , BDRV_chCfg_pwm , BDRV_chCfg_pwm );
  
  /*****************************************************************************
  ** Main endless loop                                                        **
  *****************************************************************************/
  for (;;)
  {
    /* Main watchdog service */
    (void)PMU_serviceFailSafeWatchdog();
    
    /***************************************************************************
    ** Place your application code here                                       **
    ***************************************************************************/
    
    
  }
}

void capture_PWM_MON(void)
{
	uint32 DC;
	DC= T21->RC.reg;
	T21_stop();
	T21->CNT.reg= 0;
	if (DC != 0)
	CCU7_setCC70AValShadow((uint16)DC);
}

void T12_PM (void)
{
	CCU7_setT12ShadowTransferReq();
}

