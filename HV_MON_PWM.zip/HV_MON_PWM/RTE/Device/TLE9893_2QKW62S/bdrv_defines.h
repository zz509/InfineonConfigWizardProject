/**
 * @cond
 ***********************************************************************************************************************
 *
 * Copyright (c) 2018, Infineon Technologies AG
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,are permitted provided that the
 * following conditions are met:
 *
 *   Redistributions of source code must retain the above copyright notice, this list of conditions and the  following
 *   disclaimer.
 *
 *   Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
 *   following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 *   Neither the name of the copyright holders nor the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **********************************************************************************************************************/
#ifndef BDRV_DEFINES_H
#define BDRV_DEFINES_H

/* XML Version 0.0.5 */
#define BDRV_XML_VERSION (00005)

#define BDRV_ASEQC (0x0) /*decimal 0*/

#define BDRV_ASEQERRCNT (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY_HS1T1OFFADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY_HS2T1OFFADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY_HS3T1OFFADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY_LS1T1OFFADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY_LS2T1OFFADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQOFFADDDLY_LS3T1OFFADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQOFFIMAX (0x0) /*decimal 0*/

#define BDRV_ASEQOFFIMIN (0x0) /*decimal 0*/

#define BDRV_ASEQOFFTMAX (0x0) /*decimal 0*/

#define BDRV_ASEQOFFTMIN (0x0) /*decimal 0*/

#define BDRV_ASEQONADDDLY_HS1T1ONADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQONADDDLY_HS2T1ONADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQONADDDLY_HS3T1ONADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQONADDDLY_LS1T1ONADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQONADDDLY_LS2T1ONADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQONADDDLY_LS3T1ONADDDLY_MATH (0x0) /*decimal 0*/

#define BDRV_ASEQONIMAX (0x0) /*decimal 0*/

#define BDRV_ASEQONIMIN (0x0) /*decimal 0*/

#define BDRV_ASEQONTMAX (0x0) /*decimal 0*/

#define BDRV_ASEQONTMIN (0x0) /*decimal 0*/

#define BDRV_BEMFC_CTRL (0x0) /*decimal 0*/

#define BDRV_CP_CLK_CTRL (0x1401F) /*decimal 81951*/

#define BDRV_CP_CTRL (0x1) /*decimal 1*/

#define BDRV_CTRL1 (0x0) /*decimal 0*/

#define BDRV_CTRL2 (0x10000) /*decimal 65536*/

#define BDRV_GLOBCONF_EN (0x1) /*decimal 1*/

#define BDRV_HB1IGATECLMPC (0x404) /*decimal 1028*/

#define BDRV_HB2IGATECLMPC (0x404) /*decimal 1028*/

#define BDRV_HB3IGATECLMPC (0x404) /*decimal 1028*/

#define BDRV_HCDIS (0x1003F) /*decimal 65599*/

#define BDRV_HS1CONSTIC (0x1616) /*decimal 5654*/

#define BDRV_HS1CONSTTC (0x1414) /*decimal 5140*/

#define BDRV_HS1SEQOFFIC (0x70720) /*decimal 460576*/

#define BDRV_HS1SEQOFFIC_HS1_I1OFF_MATH (0x20) /*decimal 32*/

#define BDRV_HS1SEQOFFIC_HS1_I2OFF_MATH (0x7) /*decimal 7*/

#define BDRV_HS1SEQOFFIC_HS1_I3OFF_MATH (0x7) /*decimal 7*/

#define BDRV_HS1SEQOFFIC_HS1_I4OFF_MATH (0x20) /*decimal 32*/

#define BDRV_HS1SEQOFFTC (0x50506) /*decimal 328966*/

#define BDRV_HS1SEQOFFTC_HS1_T1OFF_MATH (0x6) /*decimal 6*/

#define BDRV_HS1SEQOFFTC_HS1_T2OFF_MATH (0x5) /*decimal 5*/

#define BDRV_HS1SEQOFFTC_HS1_T3OFF_MATH (0x5) /*decimal 5*/

#define BDRV_HS1SEQOFFTC_HS1_T4OFF_MATH (0x4) /*decimal 4*/

#define BDRV_HS1SEQONIC (0x20070720) /*decimal 537331488*/

#define BDRV_HS1SEQONIC_HS1_I1ON_MATH (0x20) /*decimal 32*/

#define BDRV_HS1SEQONIC_HS1_I2ON_MATH (0x7) /*decimal 7*/

#define BDRV_HS1SEQONIC_HS1_I3ON_MATH (0x7) /*decimal 7*/

#define BDRV_HS1SEQONIC_HS1_I4ON_MATH (0x20) /*decimal 32*/

#define BDRV_HS1SEQONTC (0x4050506) /*decimal 67437830*/

#define BDRV_HS1SEQONTC_HS1_T1ON_MATH (0x6) /*decimal 6*/

#define BDRV_HS1SEQONTC_HS1_T2ON_MATH (0x5) /*decimal 5*/

#define BDRV_HS1SEQONTC_HS1_T3ON_MATH (0x5) /*decimal 5*/

#define BDRV_HS1SEQONTC_HS1_T4ON_MATH (0x4) /*decimal 4*/

#define BDRV_HS2CONSTIC (0x1616) /*decimal 5654*/

#define BDRV_HS2CONSTTC (0x1414) /*decimal 5140*/

#define BDRV_HS2SEQOFFIC (0x70720) /*decimal 460576*/

#define BDRV_HS2SEQOFFIC_HS2_I1OFF_MATH (0x20) /*decimal 32*/

#define BDRV_HS2SEQOFFIC_HS2_I2OFF_MATH (0x7) /*decimal 7*/

#define BDRV_HS2SEQOFFIC_HS2_I3OFF_MATH (0x7) /*decimal 7*/

#define BDRV_HS2SEQOFFIC_HS2_I4OFF_MATH (0x20) /*decimal 32*/

#define BDRV_HS2SEQOFFTC (0x50506) /*decimal 328966*/

#define BDRV_HS2SEQOFFTC_HS2_T1OFF_MATH (0x6) /*decimal 6*/

#define BDRV_HS2SEQOFFTC_HS2_T2OFF_MATH (0x5) /*decimal 5*/

#define BDRV_HS2SEQOFFTC_HS2_T3OFF_MATH (0x5) /*decimal 5*/

#define BDRV_HS2SEQOFFTC_HS2_T4OFF_MATH (0x4) /*decimal 4*/

#define BDRV_HS2SEQONIC (0x20070720) /*decimal 537331488*/

#define BDRV_HS2SEQONIC_HS2_I1ON_MATH (0x20) /*decimal 32*/

#define BDRV_HS2SEQONIC_HS2_I2ON_MATH (0x7) /*decimal 7*/

#define BDRV_HS2SEQONIC_HS2_I3ON_MATH (0x7) /*decimal 7*/

#define BDRV_HS2SEQONIC_HS2_I4ON_MATH (0x20) /*decimal 32*/

#define BDRV_HS2SEQONTC (0x4050506) /*decimal 67437830*/

#define BDRV_HS2SEQONTC_HS2_T1ON_MATH (0x6) /*decimal 6*/

#define BDRV_HS2SEQONTC_HS2_T2ON_MATH (0x5) /*decimal 5*/

#define BDRV_HS2SEQONTC_HS2_T3ON_MATH (0x5) /*decimal 5*/

#define BDRV_HS2SEQONTC_HS2_T4ON_MATH (0x4) /*decimal 4*/

#define BDRV_HS3CONSTIC (0x1616) /*decimal 5654*/

#define BDRV_HS3CONSTTC (0x1414) /*decimal 5140*/

#define BDRV_HS3SEQOFFIC (0x70720) /*decimal 460576*/

#define BDRV_HS3SEQOFFIC_HS3_I1OFF_MATH (0x20) /*decimal 32*/

#define BDRV_HS3SEQOFFIC_HS3_I2OFF_MATH (0x7) /*decimal 7*/

#define BDRV_HS3SEQOFFIC_HS3_I3OFF_MATH (0x7) /*decimal 7*/

#define BDRV_HS3SEQOFFIC_HS3_I4OFF_MATH (0x20) /*decimal 32*/

#define BDRV_HS3SEQOFFTC (0x50506) /*decimal 328966*/

#define BDRV_HS3SEQOFFTC_HS3_T1OFF_MATH (0x6) /*decimal 6*/

#define BDRV_HS3SEQOFFTC_HS3_T2OFF_MATH (0x5) /*decimal 5*/

#define BDRV_HS3SEQOFFTC_HS3_T3OFF_MATH (0x5) /*decimal 5*/

#define BDRV_HS3SEQOFFTC_HS3_T4OFF_MATH (0x4) /*decimal 4*/

#define BDRV_HS3SEQONIC (0x20070720) /*decimal 537331488*/

#define BDRV_HS3SEQONIC_HS3_I1ON_MATH (0x20) /*decimal 32*/

#define BDRV_HS3SEQONIC_HS3_I2ON_MATH (0x7) /*decimal 7*/

#define BDRV_HS3SEQONIC_HS3_I3ON_MATH (0x7) /*decimal 7*/

#define BDRV_HS3SEQONIC_HS3_I4ON_MATH (0x20) /*decimal 32*/

#define BDRV_HS3SEQONTC (0x4050506) /*decimal 67437830*/

#define BDRV_HS3SEQONTC_HS3_T1ON_MATH (0x6) /*decimal 6*/

#define BDRV_HS3SEQONTC_HS3_T2ON_MATH (0x5) /*decimal 5*/

#define BDRV_HS3SEQONTC_HS3_T3ON_MATH (0x5) /*decimal 5*/

#define BDRV_HS3SEQONTC_HS3_T4ON_MATH (0x4) /*decimal 4*/

#define BDRV_LS1CONSTIC (0x1616) /*decimal 5654*/

#define BDRV_LS1CONSTTC (0x1414) /*decimal 5140*/

#define BDRV_LS1SEQOFFIC (0x70720) /*decimal 460576*/

#define BDRV_LS1SEQOFFIC_LS1_I1OFF_MATH (0x20) /*decimal 32*/

#define BDRV_LS1SEQOFFIC_LS1_I2OFF_MATH (0x7) /*decimal 7*/

#define BDRV_LS1SEQOFFIC_LS1_I3OFF_MATH (0x7) /*decimal 7*/

#define BDRV_LS1SEQOFFIC_LS1_I4OFF_MATH (0x20) /*decimal 32*/

#define BDRV_LS1SEQOFFTC (0x50506) /*decimal 328966*/

#define BDRV_LS1SEQOFFTC_LS1_T1OFF_MATH (0x6) /*decimal 6*/

#define BDRV_LS1SEQOFFTC_LS1_T2OFF_MATH (0x5) /*decimal 5*/

#define BDRV_LS1SEQOFFTC_LS1_T3OFF_MATH (0x5) /*decimal 5*/

#define BDRV_LS1SEQOFFTC_LS1_T4OFF_MATH (0x4) /*decimal 4*/

#define BDRV_LS1SEQONIC (0x20070720) /*decimal 537331488*/

#define BDRV_LS1SEQONIC_LS1_I1ON_MATH (0x20) /*decimal 32*/

#define BDRV_LS1SEQONIC_LS1_I2ON_MATH (0x7) /*decimal 7*/

#define BDRV_LS1SEQONIC_LS1_I3ON_MATH (0x7) /*decimal 7*/

#define BDRV_LS1SEQONIC_LS1_I4ON_MATH (0x20) /*decimal 32*/

#define BDRV_LS1SEQONTC (0x4050506) /*decimal 67437830*/

#define BDRV_LS1SEQONTC_LS1_T1ON_MATH (0x6) /*decimal 6*/

#define BDRV_LS1SEQONTC_LS1_T2ON_MATH (0x5) /*decimal 5*/

#define BDRV_LS1SEQONTC_LS1_T3ON_MATH (0x5) /*decimal 5*/

#define BDRV_LS1SEQONTC_LS1_T4ON_MATH (0x4) /*decimal 4*/

#define BDRV_LS2CONSTIC (0x1616) /*decimal 5654*/

#define BDRV_LS2CONSTTC (0x1414) /*decimal 5140*/

#define BDRV_LS2SEQOFFIC (0x70720) /*decimal 460576*/

#define BDRV_LS2SEQOFFIC_LS2_I1OFF_MATH (0x20) /*decimal 32*/

#define BDRV_LS2SEQOFFIC_LS2_I2OFF_MATH (0x7) /*decimal 7*/

#define BDRV_LS2SEQOFFIC_LS2_I3OFF_MATH (0x7) /*decimal 7*/

#define BDRV_LS2SEQOFFIC_LS2_I4OFF_MATH (0x20) /*decimal 32*/

#define BDRV_LS2SEQOFFTC (0x50506) /*decimal 328966*/

#define BDRV_LS2SEQOFFTC_LS2_T1OFF_MATH (0x6) /*decimal 6*/

#define BDRV_LS2SEQOFFTC_LS2_T2OFF_MATH (0x5) /*decimal 5*/

#define BDRV_LS2SEQOFFTC_LS2_T3OFF_MATH (0x5) /*decimal 5*/

#define BDRV_LS2SEQOFFTC_LS2_T4OFF_MATH (0x4) /*decimal 4*/

#define BDRV_LS2SEQONIC (0x20070720) /*decimal 537331488*/

#define BDRV_LS2SEQONIC_LS2_I1ON_MATH (0x20) /*decimal 32*/

#define BDRV_LS2SEQONIC_LS2_I2ON_MATH (0x7) /*decimal 7*/

#define BDRV_LS2SEQONIC_LS2_I3ON_MATH (0x7) /*decimal 7*/

#define BDRV_LS2SEQONIC_LS2_I4ON_MATH (0x20) /*decimal 32*/

#define BDRV_LS2SEQONTC (0x4050506) /*decimal 67437830*/

#define BDRV_LS2SEQONTC_LS2_T1ON_MATH (0x6) /*decimal 6*/

#define BDRV_LS2SEQONTC_LS2_T2ON_MATH (0x5) /*decimal 5*/

#define BDRV_LS2SEQONTC_LS2_T3ON_MATH (0x5) /*decimal 5*/

#define BDRV_LS2SEQONTC_LS2_T4ON_MATH (0x4) /*decimal 4*/

#define BDRV_LS3CONSTIC (0x1616) /*decimal 5654*/

#define BDRV_LS3CONSTTC (0x1414) /*decimal 5140*/

#define BDRV_LS3SEQOFFIC (0x70720) /*decimal 460576*/

#define BDRV_LS3SEQOFFIC_LS3_I1OFF_MATH (0x20) /*decimal 32*/

#define BDRV_LS3SEQOFFIC_LS3_I2OFF_MATH (0x7) /*decimal 7*/

#define BDRV_LS3SEQOFFIC_LS3_I3OFF_MATH (0x7) /*decimal 7*/

#define BDRV_LS3SEQOFFIC_LS3_I4OFF_MATH (0x20) /*decimal 32*/

#define BDRV_LS3SEQOFFTC (0x50506) /*decimal 328966*/

#define BDRV_LS3SEQOFFTC_LS3_T1OFF_MATH (0x6) /*decimal 6*/

#define BDRV_LS3SEQOFFTC_LS3_T2OFF_MATH (0x5) /*decimal 5*/

#define BDRV_LS3SEQOFFTC_LS3_T3OFF_MATH (0x5) /*decimal 5*/

#define BDRV_LS3SEQOFFTC_LS3_T4OFF_MATH (0x4) /*decimal 4*/

#define BDRV_LS3SEQONIC (0x20070720) /*decimal 537331488*/

#define BDRV_LS3SEQONIC_LS3_I1ON_MATH (0x20) /*decimal 32*/

#define BDRV_LS3SEQONIC_LS3_I2ON_MATH (0x7) /*decimal 7*/

#define BDRV_LS3SEQONIC_LS3_I3ON_MATH (0x7) /*decimal 7*/

#define BDRV_LS3SEQONIC_LS3_I4ON_MATH (0x20) /*decimal 32*/

#define BDRV_LS3SEQONTC (0x4050506) /*decimal 67437830*/

#define BDRV_LS3SEQONTC_LS3_T1ON_MATH (0x6) /*decimal 6*/

#define BDRV_LS3SEQONTC_LS3_T2ON_MATH (0x5) /*decimal 5*/

#define BDRV_LS3SEQONTC_LS3_T3ON_MATH (0x5) /*decimal 5*/

#define BDRV_LS3SEQONTC_LS3_T4ON_MATH (0x4) /*decimal 4*/

#define BDRV_PROT_CTRL (0x1000000) /*decimal 16777216*/

#define BDRV_PWMSRCSEL (0x261504) /*decimal 2495748*/

#define BDRV_SEQMAP (0x0) /*decimal 0*/

#define BDRV_SEQOFFT4I4 (0x0) /*decimal 0*/

#define BEMFC_GLOBCONF_EN (0x0) /*decimal 0*/

#endif /* BDRV_DEFINES_H */
