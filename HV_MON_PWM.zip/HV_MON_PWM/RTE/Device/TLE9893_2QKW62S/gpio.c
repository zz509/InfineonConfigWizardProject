/*
 ***********************************************************************************************************************
 *
 * Copyright (c) 2021, Infineon Technologies AG
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,are permitted provided that the
 * following conditions are met:
 *
 *   Redistributions of source code must retain the above copyright notice, this list of conditions and the  following
 *   disclaimer.
 *
 *   Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
 *   following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 *   Neither the name of the copyright holders nor the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **********************************************************************************************************************/

/*******************************************************************************
**                                  Includes                                  **
*******************************************************************************/

#include "gpio.h"

/*******************************************************************************
**                         Private Macro Declarations                         **
*******************************************************************************/

/*******************************************************************************
**                        Private Constant Definitions                        **
*******************************************************************************/

/*******************************************************************************
**                          Private Type Declarations                         **
*******************************************************************************/

/*******************************************************************************
**                        Private Variable Definitions                        **
*******************************************************************************/

/*******************************************************************************
**                        Private Function Declarations                       **
*******************************************************************************/

/*******************************************************************************
**                         Global Function Definitions                        **
*******************************************************************************/

/** \brief Initialize all CW registers of the GPIO module
 */
void GPIO_init(void)
{
  /* P0.x*/
  GPIO->P0_DIR.reg = (uint32)GPIO_P0_DIR;
  GPIO->P0_OD.reg = (uint32)GPIO_P0_OD;
  GPIO->P0_PUD.reg = (uint32)GPIO_P0_PUD;
  GPIO->P0_POCON.reg = (uint32)GPIO_P0_POCON;
  GPIO->P0_ALTSEL0.reg = (uint32)GPIO_P0_ALTSEL0;
  GPIO->P0_ALTSEL1.reg = (uint32)GPIO_P0_ALTSEL1;
  GPIO->P0_OUT.reg = (uint32)GPIO_P0_OUT;
  /* P1.x */
  GPIO->P1_DIR.reg = (uint32)GPIO_P1_DIR;
  GPIO->P1_OD.reg = (uint32)GPIO_P1_OD;
  GPIO->P1_PUD.reg = (uint32)GPIO_P1_PUD;
  GPIO->P1_POCON.reg = (uint32)GPIO_P1_POCON;
  GPIO->P1_ALTSEL0.reg = (uint32)GPIO_P1_ALTSEL0;
  GPIO->P1_OUT.reg = (uint32)GPIO_P1_OUT;
  /* P2.x */
  GPIO->P2_INDIS.reg = (uint32)GPIO_P2_INDIS;
  GPIO->P2_PUD.reg = (uint32)GPIO_P2_PUD;
}

/*******************************************************************************
**                        Private Function Definitions                        **
*******************************************************************************/

