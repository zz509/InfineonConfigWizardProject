/*
 ***********************************************************************************************************************
 *
 * Copyright (c) 2021, Infineon Technologies AG
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,are permitted provided that the
 * following conditions are met:
 *
 *   Redistributions of source code must retain the above copyright notice, this list of conditions and the  following
 *   disclaimer.
 *
 *   Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
 *   following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 *   Neither the name of the copyright holders nor the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **********************************************************************************************************************/

/*******************************************************************************
**                             Author(s) Identity                             **
********************************************************************************
** Initials     Name                                                          **
** ---------------------------------------------------------------------------**
** DM           Daniel Mysliwitz                                              **
** BG           Blandine Guillot                                              **
** JO           Julia Ott                                                     **
** EE           Erich Englbrecht                                              **
*******************************************************************************/

/*******************************************************************************
**                          Revision Control History                          **
********************************************************************************
** V1.0.0: 2021-04-28, EE:   EP-682: Initial version                          **
*******************************************************************************/

/*******************************************************************************
**                                  Abstract                                  **
********************************************************************************
** CCU7: Generating 3 different PWM signals with CCU7                         **
********************************************************************************
** The timer T12 from the module CCU7 is started.                             **
** Three pwm signals are configured with a period of 50us.                    **
**    1. P1.2 (CCU70) ___|****|___ (edge at 25% and 75%)                      **
**    2. P1.0 (CCU71) ______|*|___ (edge at 50% and 75%)                      **
**    3. P0.9 (CCU72) _|********|_ (edge at 10% and 90%) - only for 64 pins   **
** The three COUT7x pins are configured to modulate the appropriate inverted  **
** signal.                                                                    **
*******************************************************************************/

/*******************************************************************************
**                                  Includes                                  **
*******************************************************************************/
#include "tle_device.h"
#include "types.h"


sint32 main(void)
{

  PMU_clrFailSafeWatchdogFailSts();

  /* Initialization of hardware modules based on Config Wizard configuration */
  (void) TLE_init();

  /* Clear fail safe status flags */
  while (PMU->FS_STS.reg != 0)
  {
    PMU->FS_STS_CLR.reg = 0xFFFFFFFFU;
  }
  while (PMU->FS_SSD.reg != 0)
  {
    PMU->FS_SSD_CLR.reg = 0xFFFFFFFFU;
  }

  /* Clear bridge driver status flags */
  BDRV->STSCLR.reg = 0xFFFFFFFFU;

  /* Start timer T12 */
	BDRV_setBridge(BDRV_chCfg_pwm,BDRV_chCfg_pwm,BDRV_chCfg_pwm,BDRV_chCfg_pwm,BDRV_chCfg_en,BDRV_chCfg_on); //connect load between HB1/2 and HB3(GND)
  CCU7_startT12();

//  
  for (;;)
  {
    /* Main watchdog service */
    (void) PMU_serviceFailSafeWatchdog();
  }
}

void T12_PM_ISR (void)
{
	if (BDRV->HB2OFFVAL.bit.HB2_OFFVALVF == 1)  //check if last measurement was valid
		BDRV->HB2OFFVAL.bit.HB2_OFFVALVF_CLR = 1;  //request update of measurement
}

void C71B_CM_ISR (void)
{
		if (BDRV->HB2ONVAL.bit.HB2_ONVALVF == 1) //check if last measurement was valid
			BDRV->HB2ONVAL.bit.HB2_ONVALVF_CLR = 1;	//request update of measurement
}

