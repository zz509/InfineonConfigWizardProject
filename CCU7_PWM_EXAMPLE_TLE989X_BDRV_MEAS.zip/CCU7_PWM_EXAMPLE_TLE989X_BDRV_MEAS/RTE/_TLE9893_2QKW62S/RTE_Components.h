
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'TLE9893_2QKW62S_CCU7_PWM' 
 * Target:  'TLE9893_2QKW62S' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "tle989x.h"

/* Infineon::Device:ConfigWizard:0.0.0 */
#define CONFIGWIZARD 2
/* Infineon::Device:Device Step: AA:0.0.1 */
#define RTE_DEVICE_AA_STEP
/* Infineon::Device:TLELib:ADC1:0.4.4 */
#define RTE_DEVICE_TLELIB_ADC1
/* Infineon::Device:TLELib:ADC2:0.5.1 */
#define RTE_DEVICE_TLELIB_ADC2
/* Infineon::Device:TLELib:BDRV:0.7.4 */
#define RTE_DEVICE_TLELIB_BDRV
/* Infineon::Device:TLELib:BOOTROM:0.2.2 */
#define RTE_DEVICE_TLELIB_BOOTROM
/* Infineon::Device:TLELib:CCU7:0.3.7 */
#define RTE_DEVICE_TLELIB_CCU7
/* Infineon::Device:TLELib:CSACSC:0.2.2 */
#define RTE_DEVICE_TLELIB_CSACSC
/* Infineon::Device:TLELib:GPIO:0.2.3 */
#define RTE_DEVICE_TLELIB_GPIO
/* Infineon::Device:TLELib:INT:0.2.8 */
#define RTE_DEVICE_TLELIB_INT
/* Infineon::Device:TLELib:ISR:0.4.6 */
#define RTE_DEVICE_TLELIB_ISR
/* Infineon::Device:TLELib:PMU:0.5.2 */
#define RTE_DEVICE_TLELIB_PMU
/* Infineon::Device:TLELib:SCU:0.4.4 */
#define RTE_DEVICE_TLELIB_SCU


#endif /* RTE_COMPONENTS_H */
